<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/json");

include "db.php";

if (!isset($_GET['food_id'])) {
    echo json_encode([
        "success" => false,
        "message" => "Food ID is required"
    ]);
    exit;
}

$id = intval($_GET['food_id']);

$query = "SELECT * FROM foods WHERE food_id = $id LIMIT 1";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $food = mysqli_fetch_assoc($result);
    echo json_encode([
        "success" => true,
        "food" => $food
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Food not found"
    ]);
}

mysqli_close($conn);
?>
