<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json");

include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$order_id = $data["order_id"] ?? null;
$status = $data["status"] ?? null;

if (!$order_id || !$status) {
    echo json_encode(["success" => false, "message" => "Invalid data"]);
    exit;
}

$sql = "UPDATE orders SET status = '$status' WHERE order_id = '$order_id'";

if (mysqli_query($conn, $sql)) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "message" => mysqli_error($conn)]);
}
?>
