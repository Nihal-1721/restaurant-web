<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

require_once "db.php";

$sql = "SELECT * FROM foods ORDER BY food_id ASC";
$res = mysqli_query($conn, $sql);

$foods = [];
while($row = mysqli_fetch_assoc($res)) {
    $foods[] = $row;
}

echo json_encode([
    "success" => true,
    "foods" => $foods
]);
?>
