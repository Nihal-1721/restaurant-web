<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
include "db.php";

$response = ["success" => false, "message" => ""];

if (!isset($_POST["name"]) || !isset($_POST["price"]) || !isset($_POST["category_name"]) || !isset($_POST["description"])) {
    $response["message"] = "Missing required fields.";
    echo json_encode($response);
    exit;
}

$name = $_POST["name"];
$price = $_POST["price"];
$category_name = $_POST["category_name"];
$description = $_POST["description"];
$image_url = "";

$sql = "INSERT INTO foods (name, price, category_name, description) 
        VALUES ('$name', '$price', '$category_name', '$description')";

if (mysqli_query($conn, $sql)) {
    $response["success"] = true;
    $response["message"] = "Food added successfully!";
} else {
    $response["message"] = "Database error: " . mysqli_error($conn);
}

echo json_encode($response);
?>
