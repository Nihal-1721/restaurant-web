<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$servername = "localhost";
$username = "root"; // change if needed
$password = ""; // change if needed
$dbname = "restaurant_app"; // change to your DB name

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Database connection failed"]));
}

// Get JSON data from frontend
$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['full_name'], $data['email'], $data['phone'],$data['password'])) {
    echo json_encode(["success" => false, "message" => "Missing fields"]);
    exit;
}

$full_name = $conn->real_escape_string($data['full_name']);
$email = $conn->real_escape_string($data['email']);
$phone = $conn->real_escape_string($data['phone']);
$password = password_hash($data['password'], PASSWORD_BCRYPT);

// Check if email already exists
$check = $conn->query("SELECT * FROM admins WHERE email='$email'");
if ($check->num_rows > 0) {
    echo json_encode(["success" => false, "message" => "Email already registered"]);
    exit;
}

// Insert into database
$sql = "INSERT INTO admins (full_name, email, phone, password_hash) 
        VALUES ('$full_name', '$email', '$phone', '$password')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true, "message" => "Admin registered successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Error: " . $conn->error]);
}

$conn->close();
?>
