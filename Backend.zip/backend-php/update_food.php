<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/json");

include "db.php";

if (!isset($_POST['id'])) {
    echo json_encode([
        "success" => false,
        "message" => "Food ID is required"
    ]);
    exit;
}

$food_id = $_POST['id'];
$name = $_POST['name'];
$price = $_POST['price'];
$category = $_POST['category_name'];
$description = $_POST['description'];

$query = "UPDATE foods SET 
            name='$name',
            price='$price',
            category_name='$category',
            description='$description'
          WHERE food_id='$food_id'";

if (mysqli_query($conn, $query)) {
    echo json_encode([
        "success" => true,
        "message" => "Food Updated Successfully"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => mysqli_error($conn)
    ]);
}
