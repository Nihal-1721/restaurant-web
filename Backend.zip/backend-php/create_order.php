<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

// Handle CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

include "db.php";

// Read raw JSON
$raw = file_get_contents("php://input");
file_put_contents("debug_order.txt", $raw); // debugging

$data = json_decode($raw, true);

// Validate that JSON contains the keys
if (!$data || !isset($data["orderData"]) || !isset($data["orderItems"])) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid payload structure",
        "received" => $data
    ]);
    exit;
}

// Extract main order data
$orderData = $data["orderData"];
$orderItems = $data["orderItems"];

$user_id = $orderData["user_id"];
$delivery_address = $orderData["delivery_address"];
$total_amount = $orderData["total_amount"];
$status = $orderData["status"];
$order_date = $orderData["order_date"];

// Insert into orders
$sql = "INSERT INTO orders (user_id, total_amount, status, order_date, delivery_address)
        VALUES ('$user_id', '$total_amount', '$status', '$order_date', '$delivery_address')";

if (!mysqli_query($conn, $sql)) {
    echo json_encode([
        "success" => false,
        "message" => "Order insert failed",
        "error" => mysqli_error($conn)
    ]);
    exit;
}

$order_id = mysqli_insert_id($conn);

// Insert each order item
foreach ($orderItems as $item) {
    $food_id = $item["food_id"];
    $quantity = $item["quantity"];
    $price = $item["price"];

    $sql_item = "INSERT INTO order_items (order_id, food_id, quantity, price_item)
                 VALUES ('$order_id', '$food_id', '$quantity', '$price')";

    if (!mysqli_query($conn, $sql_item)) {
        echo json_encode([
            "success" => false,
            "message" => "Item insert failed",
            "error" => mysqli_error($conn)
        ]);
        exit;
    }
}

echo json_encode([
    "success" => true,
    "message" => "Order created successfully",
    "order_id" => $order_id
]);
?>
