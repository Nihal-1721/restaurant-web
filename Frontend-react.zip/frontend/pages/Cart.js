// Cart.js
import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { updateCartStorage } from "../pages/cartUtils";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Cart = () => {
  const navigate = useNavigate();

  const [cart, setCart] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("cart")) || [];
    } catch {
      return [];
    }
  });

  const [showPopup, setShowPopup] = useState(false);
  const [userData, setUserData] = useState({
    name: "",
    mobile_no: "",
    address: ""
  });

  const [loading, setLoading] = useState(false);

  const subtotal = cart.reduce((sum, i) => sum + Number(i.price) * Number(i.qty), 0);
  const delivery = 3.99;
  const tax = +(subtotal * 0.08).toFixed(2);
  const total = (subtotal + delivery + tax).toFixed(2);

  const handleConfirmOrder = async () => {
    const storedUser = JSON.parse(localStorage.getItem("loggedUser"));
    if (!storedUser || !storedUser.user_id) {
      alert("You're not login yet! Please login again.");
      navigate("/login");
      return;
    }

    // ---------- ORDER MAIN DATA ----------
    const orderData = {
      user_id: storedUser.user_id,
      delivery_address: userData.address,
      total_amount: Number(total),
      status: "Pending",
      order_date: new Date().toISOString().slice(0, 19).replace("T", " ")
    };

    // ---------- ORDER ITEMS DATA ----------
    const orderItems = cart.map(item => ({
      food_id: item.food_id,
      quantity: item.qty,
      price: item.price
    }));

    // ---------- FINAL PAYLOAD ----------
    const payload = {
      orderData: orderData,
      orderItems: orderItems
    };

    try {
      const res = await axios.post(
        "http://localhost/backend-php/create_order.php",
        JSON.stringify(payload),
        {
          headers: { "Content-Type": "application/json" }
        }
      );

      console.log("Order response:", res.data);

      if (res.data.success) {
        alert("Order Confirmed Successfully!");

        localStorage.setItem("last_order_id", res.data.order_id);
        localStorage.removeItem("cart");
        setCart([]);

        setShowPopup(false);

        setTimeout(() => {
          if (window.confirm("Order Placed! Download Invoice?")) {
            window.location.href =
              `http://localhost/backend-php/download_invoice.php?order_id=${res.data.order_id}`;
          }
        }, 300);
      } else {
        alert(res.data.message || "Order failed! Try again.");
      }
    } catch (err) {
      console.log(err);
      alert("Error placing order!");
    }
  };

  const handleCheckout = async () => {
    const storedUserRaw = localStorage.getItem("loggedUser");

    if (!storedUserRaw) {
      alert("You're not login yet!! Please login first");
      navigate("/login");
      return;
    }

    let user;
    try {
      user = JSON.parse(storedUserRaw);
    } catch {
      alert("Invalid user data. Please login again.");
      navigate("/login");
      return;
    }

    if (!user.user_id) {
      alert("You're not login yet!! Please login first");
      navigate("/login");
      return;
    }

    try {
      const res = await axios.get(
        `http://localhost/backend-php/get_user.php?user_id=${user.user_id}`
      );

      console.log("Response from backend:", res.data);
      if (res.data && res.data.success === true && res.data.user) {
        setUserData({
          name: res.data.user.full_name || "",
          mobile_no: res.data.user.phone || "",
          address: res.data.user.address || ""
        });
        setShowPopup(true);
      } else {
        alert("User not found or error fetching user.");
      }
    } catch (err) {
      console.log("Error fetching user:", err);
      alert("Unable to fetch user data!");
    }
  };

  // ---------------- UPDATE QTY ----------------
  const updateQty = (id, delta) => {
    const updated = cart.map(item =>
      item.food_id === id
        ? { ...item, qty: Math.max(1, Number(item.qty) + Number(delta)) }
        : item
    );

    setCart(updated);
    updateCartStorage(updated);
  };

  // ---------------- REMOVE ITEM ----------------
  const removeItem = (id) => {
    const updated = cart.filter(item => item.food_id !== id);
    setCart(updated);
    updateCartStorage(updated);
  };

  return (
    <>
      <section className="cart">
        <div className="container">
          <h2>Your Cart</h2>

          <div className="cart-content">
            <div className="cart-items">
              {cart.length === 0 && <p>Your cart is empty.</p>}

              {cart.map(item => (
                <div className="cart-item" key={item.food_id}>
                  <img src={item.img} alt={item.name} />
                  <div className="item-details">
                    <h3>{item.name}</h3>
                    <p>{item.desc}</p>

                    <div className="item-controls">
                      <button
                        className="quantity-btn"
                        onClick={() => updateQty(item.food_id, -1)}
                        disabled={loading}
                      >
                        -
                      </button>

                      <span className="quantity">{item.qty}</span>

                      <button
                        className="quantity-btn"
                        onClick={() => updateQty(item.food_id, 1)}
                        disabled={loading}
                      >
                        +
                      </button>

                      <span className="price">₹{(Number(item.price) * Number(item.qty)).toFixed(2)}</span>

                      <button
                        className="remove-item"
                        onClick={() => removeItem(item.food_id)}
                        disabled={loading}
                      >
                        <FontAwesomeIcon icon={faTrash} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="cart-summary">
              <h3>Order Summary</h3>
              <div className="summary-details">
                <div className="summary-row"><span>Subtotal</span><span>₹{subtotal.toFixed(2)}</span></div>
                <div className="summary-row"><span>Delivery Fee</span><span>₹{delivery.toFixed(2)}</span></div>
                <div className="summary-row"><span>Tax (8%)</span><span>₹{tax}</span></div>
                <div className="summary-row total"><span>Total</span><span>₹{total}</span></div>
              </div>

              <button
                className="btn checkout-btn"
                onClick={handleCheckout}
                disabled={loading || cart.length === 0}
              >
                {loading ? "Please wait..." : "Proceed to Checkout"}
              </button>

              <button className="btn continue-shopping" onClick={() => navigate("/foods")} disabled={loading}>
                Continue Shopping
              </button>
            </div>
          </div>
        </div>
      </section>

      {showPopup && (
        <div className="popup-overlay">
          <div className="popup-box">
            <h2>Complete Your Order</h2>

            <input
              type="text"
              value={userData.name}
              onChange={(e) => setUserData({ ...userData, name: e.target.value })}
              placeholder="Full Name"
              disabled={loading}
            />

            <input
              type="text"
              value={userData.mobile_no}
              onChange={(e) => setUserData({ ...userData, mobile_no: e.target.value })}
              placeholder="Mobile Number"
              disabled={loading}
            />

            <textarea
              value={userData.address}
              onChange={(e) => setUserData({ ...userData, address: e.target.value })}
              placeholder="Delivery Address"
              disabled={loading}
            ></textarea>

            <div className="popup-buttons">
              <button className="btn cancel-btn" onClick={() => setShowPopup(false)} disabled={loading}>Cancel</button>
              <button className="btn confirm-btn" onClick={handleConfirmOrder} disabled={loading}>
                {loading ? "Placing order..." : "Confirm Order"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Cart;
