import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

const Login = () => {
  const [tab, setTab] = useState("login");
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [full_Name, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const navigate = useNavigate();

  const cleartab = () => {
    setFullName("");
    setEmail("");
    setPhone("");
    setAddress("");
    setPassword("");
    setConfirmPassword("");
  };

  const notifyUserUpdate = (userData) => {
    // custom event for same-tab updates
    window.dispatchEvent(new CustomEvent("userUpdated", { detail: userData }));
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost/backend-php/login.php", {
        email,
        password,
      });

      // debug: uncomment while testing
      console.log("login response:", res.data);

      if (res.data && res.data.success) {
        alert("Login successful!");

        // adapt to whatever shape your backend returns in res.data.user
        const userData = { ...res.data.user, is_admin: false };

        // store under single consistent key
        localStorage.setItem("loggedUser", JSON.stringify(userData));

        // notify navbar in same tab
        notifyUserUpdate(userData);

        cleartab();

        // optional: redirect after login
        navigate("/");
      } else {
        alert(res.data?.message || "Login failed");
      }
    } catch (err) {
      console.error(err);
      alert("Login failed. Please check your connection or credentials.");
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    try {
      const res = await axios.post("http://localhost/backend-php/register.php", {
        full_name: full_Name,
        email,
        phone,
        address,
        password,
      });

      console.log("register response:", res.data);

      if (res.data && res.data.success) {
        alert("Registration successful!");

        const userData = { ...res.data.user, is_admin: false };
        localStorage.setItem("loggedUser", JSON.stringify(userData));
        notifyUserUpdate(userData);

        cleartab();
      } else {
        alert(res.data.message || "Registration failed");
      }
    } catch (err) {
      console.error(err);
      alert("Registration failed. Please try again later.");
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    try {
      const res = await axios.post("http://localhost/backend-php/changepass.php", {
        email,
        password,
      });
      if (res.data.success) {
        alert("Password changed successfully!");
        setTab("login");
        cleartab();
      } else {
        alert(res.data.message);
      }
    } catch (err) {
      alert("Failed to change password. Please try again later.");
    }
  };

  return (
    <section className="auth-section">
      <div className="container">
        <div className="auth-container">
          <div className="auth-tabs">
            <button
              className={`auth-tab-btn ${tab === "login" ? "active" : ""}`}
              onClick={() => {
                setTab("login");
              }}
            >
              Login
            </button>
            <button
              className={`auth-tab-btn ${tab === "register" ? "active" : ""}`}
              onClick={() => {
                setTab("register");
                setShowChangePassword(false);
              }}
            >
              Register
            </button>
          </div>

          {showChangePassword ? (
            <form className="auth-form" onSubmit={handleChangePassword}>
              <h3>Change Password</h3>
              <div className="form-group">
                <label>Email</label>
                <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div className="form-group">
                <label>New Password</label>
                <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
              <div className="form-group">
                <label>Confirm Password</label>
                <input type="password" required value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
              </div>
              <button className="btn">Update Password</button>
              <button type="button" className="link-button" onClick={() => setShowChangePassword(false)}>
                Back to Login
              </button>
            </form>
          ) : tab === "login" ? (
            <form className="auth-form" onSubmit={handleLogin}>
              <div className="form-group">
                <label>Email</label>
                <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div className="form-group">
                <label>Password</label>
                <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
              <div className="form-options">
                <button type="button" className="link-button" onClick={() => setShowChangePassword(true)}>
                  Forgot password?
                </button>
              </div>
              <div>
                <center>
                  <p style={{ color: "red" }}>If you haven't registered, please register first.</p>
                </center>
              </div>
              <button className="btn" type="submit">
                Login
              </button>
            </form>
          ) : (
            <form className="auth-form" onSubmit={handleRegister}>
              <div className="form-group">
                <label>Full Name</label>
                <input type="text" required value={full_Name} onChange={(e) => setFullName(e.target.value)} />
              </div>
              <div className="form-group">
                <label>Email</label>
                <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div className="form-group">
                <label>Phone Number</label>
                <input type="tel" required value={phone} onChange={(e) => setPhone(e.target.value)} />
              </div>
              <div className="form-group">
                <label>Address</label>
                <input type="text" required value={address} onChange={(e) => setAddress(e.target.value)} />
              </div>
              <div className="form-group">
                <label>Password</label>
                <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
              <div className="form-group">
                <label>Confirm Password</label>
                <input type="password" required value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
              </div>
              <button className="btn" type="submit">
                Register
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};

export default Login;
  