import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";


const AdminLogin = () => {
  const [pin, setPin] = useState("");
  const [error, setError] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [tab, setTab] = useState("login");
  const [full_Name, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [confirmPassword, setConfirmPassword] = useState("");
  const navigate = useNavigate();

  const cleartab = (e) => {
    setFullName("");
    setEmail("");
    setPhone("");
    setPassword("");
    setConfirmPassword("");
    setShowChangePassword("");
    setTab("");
  }

  const correctPin = "1234";

  const handlePinSubmit = (e) => {
    e.preventDefault();
    if (pin === correctPin) {
      setShowAuth(true);
      setError(false);
    } else {
      setError(true);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost/backend-php/ad_login.php", {
        email,
        password,
      });
      if (res.data.success) {
        alert("Login successful!");
        const adminData = { ...res.data.user, is_admin: true };
        localStorage.setItem("loggedUser", JSON.stringify(adminData));
        window.dispatchEvent(new CustomEvent("userUpdated", { detail: adminData }));
        cleartab();
        navigate("/");
      }
    } catch (err) {
      alert("Login failed. Please check your connection or credentials.");
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    try {
      const res = await axios.post("http://localhost/backend-php/ad_register.php", {
        full_name: full_Name,
        email,
        phone,
        password,
      });
      if (res.data.success) {
        alert("Registration successful!");
        localStorage.setItem("admin", JSON.stringify(res.data.admin));
        cleartab();
      } else {
        alert(res.data.message);
      }
    } catch (err) {
      alert("Registration failed. Please try again later.");
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    try {
      const res = await axios.post("http://localhost/backend-php/ad_changepass.php", {
        email,
        password,
      });
      if (res.data.success) {
        alert("Password changed successfully!");
        cleartab();
      } else {
        alert(res.data.message);
      }
    } catch (err) {
      alert("Failed to change password. Please try again later.");
    }
  };

  return (
    <div className="admin-login-page">
      {!showAuth ? (
        <div className="pin-modal">
          <div className="pin-modal-content">
            <h2>🔐 Admin Access</h2>
            <p>Please enter your admin PIN to continue:</p>
            <form onSubmit={handlePinSubmit}>
              <input
                type="password"
                className="pin-input"
                placeholder="Enter 4-digit PIN"
                maxLength="4"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
              />
              {error && (
                <p className="pin-error">❌ Incorrect PIN. Please try again.</p>
              )}
              <button type="submit" className="btn btn-primary">
                Submit
              </button>
            </form>
          </div>
        </div>
      ) : (
        <section className="auth-section">
          <div className="container">
            <div className="auth-container">
              <div className="auth-tabs">
                <button
                  className={`auth-tab-btn ${tab === "login" ? "active" : ""}`}
                  onClick={() => setTab("login")}
                >
                  Admin Login
                </button>
                <button
                  className={`auth-tab-btn ${tab === "register" ? "active" : ""}`}
                  onClick={() => {
                    setTab("register");
                    setShowChangePassword(false);
                  }
                  }
                >
                  Admin Register
                </button>
              </div>

              {showChangePassword ? (
                <form className="auth-form" onSubmit={handleChangePassword}>
                  <h3>Change Password</h3>

                  <div className="form-group">
                    <label>Email</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>

                  <div className="form-group">
                    <label>New Password</label>
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>

                  <div className="form-group">
                    <label>Confirm Password</label>
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                    />
                  </div>

                  <button className="btn">Update Password</button>

                  <button
                    type="button"
                    className="link-button"
                    onClick={() => setShowChangePassword(false)}
                  >
                    Back to Login
                  </button>
                </form>
              ) : tab === "login" ? (
                <form className="auth-form" onSubmit={handleLogin}>
                  <div className="form-group">
                    <label>Email</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>

                  <div className="form-group">
                    <label>Password</label>
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>

                  <div className="form-options">
                    <button
                      type="button"
                      className="link-button"
                      onClick={() => setShowChangePassword(true)}
                    >
                      Forgot password?
                    </button>
                  </div>

                  <div><center><p style={{ color: "red" }}>If you haven't registered, please register first.</p></center></div>

                  <button className="btn" type="submit">
                    Login
                  </button>
                </form>
              ) : (
                <form className="auth-form" onSubmit={handleRegister}>
                  <div className="form-group">
                    <label>Full Name</label>
                    <input
                      type="text"
                      required
                      value={full_Name}
                      onChange={(e) => setFullName(e.target.value)}
                    />
                  </div>

                  <div className="form-group">
                    <label>Email</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>

                  <div className="form-group">
                    <label>Phone Number</label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                    />
                  </div>

                  <div className="form-group">
                    <label>Password</label>
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>

                  <div className="form-group">
                    <label>Confirm Password</label>
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                    />
                  </div>

                  <button className="btn" type="submit">
                    Register
                  </button>
                </form>
              )}
            </div>
          </div>
        </section>
      )}
    </div>
  );
};

export default AdminLogin;
