import React from "react";
import "./styles/style.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faMoon,
  faShoppingCart,
  faPhone,
  faEnvelope,
  faMapMarkerAlt,
} from "@fortawesome/free-solid-svg-icons";
import {
  faFacebook,
  faInstagram,
  faTwitter,
  faYoutube,
} from "@fortawesome/free-brands-svg-icons";

const HomePage = () => {
  return (
    <>
      {/* Navigation Bar */}
      <nav className="navbar">
        <div className="container">
          <img className="logo-img" src="image/main logo.png" alt="Logo" />
          <a href="/" className="logo">
            All In One Multi Cuisine Restaurant
          </a>
          <ul className="nav-links">
            <li>
              <a href="/" className="active">
                Home
              </a>
            </li>
            <li>
              <a href="/categories">Categories</a>
            </li>
            <li>
              <a href="/foods">Menu</a>
            </li>
            <li>
              <a href="/orders">Orders</a>
            </li>
            <li>
              <a href="/login">Login</a>
            </li>
            <li>
              <a href="/admin_login" id="admin-login-link">
                Admin Login
              </a>
            </li>
            <li>
              <a href="/cart">
              <i class="fas fa-shopping-cart"></i>
                {/* <FontAwesomeIcon icon={faShoppingCart} /> */}
                 Cart
              </a>
            </li>
            <li>
              <button id="theme-toggle" className="theme-toggle">
                <FontAwesomeIcon icon={faMoon} />
              </button>
            </li>
          </ul>
          <div className="hamburger">
            <span></span>
            <span></span>
            <span></span>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero">
        <div className="container">
          <h1>Welcome to All In One Multi Cuisine Restaurant</h1>
          <p>
            Experience culinary excellence with our handcrafted dishes made from
            the finest ingredients
          </p>
          <a href="/foods" className="btn">
            Explore Menu
          </a>
        </div>
      </section>

      {/* About Section */}
      <section className="about">
        <div className="container">
          <h2>About Our Restaurant</h2>
          <div className="about-content">
            <div className="about-text">
              <p>
                Founded in 2010, Gourmet Haven has been serving authentic cuisine
                with a modern twist. Our chefs combine traditional recipes with
                innovative techniques to create unforgettable dining experiences.
              </p>
              <p>
                We source our ingredients locally whenever possible, ensuring
                freshness and supporting our community. Our menu changes
                seasonally to reflect the best produce available.
              </p>
            </div>
            <div className="about-image">
              <img
                src="image/restaurant-interior.jpg"
                alt="Restaurant Interior"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Special Offers */}
      <section className="offers">
        <div className="container">
          <h2>Today's Specials</h2>
          <div className="offer-items">
            <div className="offer-item">
              <img src="image/menu_10.jpg" alt="Special Dish 1" />
              <h3>Truffle Pasta</h3>
              <p className="price">
                $18.99 <span className="old-price">$24.99</span>
              </p>
            </div>
            <div className="offer-item">
              <img src="image/menu_4.jpg" alt="Special Dish 2" />
              <h3>Grilled Salmon</h3>
              <p className="price">
                $22.99 <span className="old-price">$28.99</span>
              </p>
            </div>
            <div className="offer-item">
              <img src="image/menu_19.jpg" alt="Special Dish 3" />
              <h3>Chocolate Fondant</h3>
              <p className="price">
                $9.99 <span className="old-price">$12.99</span>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <div className="footer-content">
            <div className="footer-section about">
              <h3>All In One Multi Cuisine Restaurant</h3>
              <p>
                Fine dining experience with a focus on quality ingredients and
                exceptional service.
              </p>
              <div className="contact">
                <span>
                  <FontAwesomeIcon icon={faPhone} /> (123) 456-7890
                </span>
                <span>
                  <FontAwesomeIcon icon={faEnvelope} /> info@gourmethaven.com
                </span>
              </div>
            </div>

            <div className="footer-section links">
              <h3>Quick Links</h3>
              <ul>
                <li>
                  <a href="/">Home</a>
                </li>
                <li>
                  <a href="/categories">Categories</a>
                </li>
                <li>
                  <a href="/foods">Our Menu</a>
                </li>
                <li>
                  <a href="/orders">Orders</a>
                </li>
                <li>
                  <a href="/login">Login</a>
                </li>
                <li>
                  <a href="/admin_login" id="admin-login-link">
                    Admin Login
                  </a>
                </li>
                <li>
                  <a href="/cart">Cart</a>
                </li>
              </ul>
            </div>

            <div className="footer-section contact-form">
              <h3>Contact Us</h3>
              <form>
                <input
                  type="email"
                  placeholder="Your Email"
                  className="text-input"
                />
                <textarea
                  placeholder="Your Message"
                  className="text-input"
                ></textarea>
                <button type="submit" className="btn">
                  Send
                </button>
              </form>
            </div>

            <div className="footer-section social">
              <h3>Follow Us</h3>
              <div className="social-links">
                <a href="#">
                  <FontAwesomeIcon icon={faFacebook} />
                </a>
                <a href="#">
                  <FontAwesomeIcon icon={faInstagram} />
                </a>
                <a href="#">
                  <FontAwesomeIcon icon={faTwitter} />
                </a>
                <a href="#">
                  <FontAwesomeIcon icon={faYoutube} />
                </a>
              </div>
              <div className="address">
                <p>
                  <FontAwesomeIcon icon={faMapMarkerAlt} /> 123 Gourmet Street,
                  Foodville, FC 12345
                </p>
              </div>
            </div>
          </div>

          <div className="footer-bottom">
            <h4>
              &copy;2023 All In One Multi Cuisine Restaurant | Designed by
              Restaurant Team
            </h4>
          </div>
        </div>
      </footer>
    </>
  );
};

export default HomePage;
