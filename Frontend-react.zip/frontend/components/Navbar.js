import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faShoppingCart, faMoon, faSun, faUser, faSignOutAlt } from "@fortawesome/free-solid-svg-icons";
import MainLogo from "../images/main-logo.png";
import { useTheme, initTheme } from "../hooks/useTheme";
import { getCartCount } from "../pages/cartUtils";

const Navbar = () => {
  const { theme, toggleTheme } = useTheme();

  const [cartCount, setCartCount] = useState(getCartCount());
  const [userInfo, setUserInfo] = useState(null);
  const [showTooltip, setShowTooltip] = useState(false);

  useEffect(() => {
    const updateCount = () => setCartCount(getCartCount());
    window.addEventListener("cartUpdated", updateCount);
    return () => window.removeEventListener("cartUpdated", updateCount);
  }, []);

  // On mount: read localStorage
  useEffect(() => {
    initTheme();
    const savedUser = localStorage.getItem("loggedUser");
    if (savedUser) {
      try {
        setUserInfo(JSON.parse(savedUser));
      } catch (err) {
        console.error("Failed to parse loggedUser:", err);
      }
    }
  }, []);

  // Listen for custom 'userUpdated' to update same-tab
  useEffect(() => {
    const onUserUpdated = (e) => {
      if (e && e.detail) {
        setUserInfo(e.detail);
      } else {
        // fallback - read localStorage
        const saved = localStorage.getItem("loggedUser");
        setUserInfo(saved ? JSON.parse(saved) : null);
      }
    };
    window.addEventListener("userUpdated", onUserUpdated);

    // Also listen for storage events (other tabs)
    const onStorage = (e) => {
      if (e.key === "loggedUser") {
        setUserInfo(e.newValue ? JSON.parse(e.newValue) : null);
      }
    };
    window.addEventListener("storage", onStorage);

    return () => {
      window.removeEventListener("userUpdated", onUserUpdated);
      window.removeEventListener("storage", onStorage);
    };
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("loggedUser");
    window.dispatchEvent(new CustomEvent("userUpdated"));
  };

  return (
    <nav className="navbar">
      <div className="container">
        <img className="logo-img" src={MainLogo} alt="Logo" />
        <Link to="/" className="logo">All In One Multi Cuisine Restaurant</Link>

        <ul className="nav-links">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/categories">Categories</Link></li>
          <li><Link to="/foods">Menu</Link></li>
          <li><Link to="/orders">Orders</Link></li>

          {!userInfo && <li><Link to="/login">Login</Link></li>}
          {!userInfo?.is_admin && <li><Link to="/admin">Admin Login</Link></li>}

          <li>
            <Link to="/cart" className="cart-icon">🛒
              {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
            </Link>
          </li>

          {userInfo && (
            <li
              className="user-info-wrapper"
              onMouseEnter={() => setShowTooltip(true)}
              onMouseLeave={() => setShowTooltip(false)}
            >
              <FontAwesomeIcon icon={faUser} className="user-info-icon" />
              {showTooltip && (
                <div className="user-tooltip">
                  <p><strong>User ID:</strong> {userInfo.user_id}</p>
                  <p><strong>Name:</strong> {userInfo.full_name}</p>
                  <p><strong>Mobile:</strong> {userInfo.phone}</p>
                  <p><strong>Address:</strong> {userInfo.address}</p>
                  <button className="btn-small" onClick={handleLogout}>
                    <FontAwesomeIcon icon={faSignOutAlt} /> Logout
                  </button>
                </div>
              )}
            </li>
          )}

          <li>
            <button id="theme-toggle" className="theme-toggle" onClick={toggleTheme}>
              <FontAwesomeIcon icon={theme === "light" ? faMoon : faSun} />
              <span>{theme === "light" ? " Dark" : " Light"}</span>
            </button>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;