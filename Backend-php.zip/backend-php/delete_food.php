<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json");

include "db.php";

// Accept both JSON & form-data
$food_id = $_POST['food_id'] ?? null;

if (!$food_id) {
    echo json_encode([
        "success" => false,
        "message" => "Food ID not received"
    ]);
    exit;
}

$query = "DELETE FROM foods WHERE food_id = $food_id";

if (mysqli_query($conn, $query)) {
    echo json_encode([
        "success" => true,
        "message" => "Food deleted"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Delete failed: " . mysqli_error($conn)
    ]);
}
?>
