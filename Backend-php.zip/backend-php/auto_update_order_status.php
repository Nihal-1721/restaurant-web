<?php
include "db.php";

$sql = "
    UPDATE orders 
    SET status = 'Delivered'
    WHERE status = 'Pending'
    AND TIMESTAMPDIFF(MINUTE, order_date, NOW()) >= 30
";

if (mysqli_query($conn, $sql)) {
    echo "Status updated successfully!";
} else {
    echo "Error: " . mysqli_error($conn);
}

?>
