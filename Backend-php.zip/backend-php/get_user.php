<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/json");

include "db.php";

if (!isset($_GET['user_id'])) {
    echo json_encode([
        "success" => false,
        "message" => "User ID is required"
    ]);
    exit;
}

$user_id = intval($_GET['user_id']);

$sql = "SELECT full_name, phone, address FROM users WHERE user_id = $user_id";
$res = mysqli_query($conn, $sql);

// ❌ Query failed
if (!$res) {
    echo json_encode([
        "success" => false,
        "message" => "SQL Error: " . mysqli_error($conn)
    ]);
    exit;
}

// ❌ No user found
if (mysqli_num_rows($res) === 0) {
    echo json_encode([
        "success" => false,
        "message" => "User not found"
    ]);
    exit;
}

// ✔ User found
$user = mysqli_fetch_assoc($res);

echo json_encode([
    "success" => true,
    "user" => $user
]);

?>
