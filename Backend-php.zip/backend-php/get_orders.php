<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

// CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

include "db.php";

// Get user_id from GET parameter
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

if ($user_id === 0) {
    echo json_encode(["success" => false, "message" => "Missing user_id"]);
    exit;
}

// Fetch all orders
$query = "SELECT * FROM orders WHERE user_id = $user_id ORDER BY order_id DESC";
$result = mysqli_query($conn, $query);

$orders = [];

while ($row = mysqli_fetch_assoc($result)) {
    $order_id = $row['order_id'];

    // Fetch items of that order
    $itemQuery = "SELECT oi.*, f.name 
                  FROM order_items oi 
                  LEFT JOIN foods f ON oi.food_id = f.food_id
                  WHERE order_id = $order_id";

    $itemResult = mysqli_query($conn, $itemQuery);

    $items = [];
    while ($item = mysqli_fetch_assoc($itemResult)) {
        $items[] = $item;
    }

    // Append items into main order
    $row['items'] = $items;

    $orders[] = $row;
}

echo json_encode([
    "success" => true,
    "orders" => $orders
]);
?>
