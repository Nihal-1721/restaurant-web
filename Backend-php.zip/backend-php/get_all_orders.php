<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

include "db.php";

// ❗ Check DB connection
if (!isset($conn) || mysqli_connect_errno()) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit;
}

// FETCH ALL ORDERS + USER DETAILS
$sql = "
    SELECT 
        o.order_id,
        o.user_id,
        u.full_name AS user_name,
        o.order_date,
        o.total_amount,
        o.status
    FROM orders o
    LEFT JOIN users u ON u.user_id = o.user_id
    ORDER BY o.order_id ASC
";

$result = mysqli_query($conn, $sql);

if (!$result) {
    echo json_encode(["success" => false, "message" => "Query Error"]);
    exit;
}

$orders = [];

while ($row = mysqli_fetch_assoc($result)) {
    $order_id = $row['order_id'];

    // FETCH ORDER ITEMS
    $item_sql = "
        SELECT 
            oi.item_id,
            oi.food_id,
            oi.quantity,
            oi.price_item,
            f.name AS name,
            f.description AS description
        FROM order_items oi
        LEFT JOIN foods f ON f.food_id = oi.food_id
        WHERE oi.order_id = '$order_id'
    ";

    $item_res = mysqli_query($conn, $item_sql);
    $items = [];

    while ($item = mysqli_fetch_assoc($item_res)) {
        $items[] = $item;
    }

    $row['items'] = $items;
    $orders[] = $row;
}

echo json_encode([
    "success" => true,
    "orders" => $orders
]);
?>
