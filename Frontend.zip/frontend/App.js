import React from "react";
import { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Categories from "./pages/Categories";
import Foods from "./pages/Foods";
import Cart from "./pages/Cart";
import Orders from "./pages/Orders";
import Login from "./pages/Login";
import AdminLogin from "./pages/AdminLogin";
import FoodForm from "./pages/FoodForm";

function App() {

  useEffect(() => {
    localStorage.setItem("user", JSON.stringify({ is_admin: false }));
    localStorage.setItem("theme", "light");
  }, []);

  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/categories" element={<Categories />} />
        <Route path="/foods" element={<Foods />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/orders" element={<Orders />} />
        <Route path="/login" element={<Login />} />
        <Route path="/admin" element={<AdminLogin />} />
        <Route path="/form/:id" element={<FoodForm />} />
        <Route path="/form" element={<FoodForm />} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;
