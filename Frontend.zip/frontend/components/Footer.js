import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPhone, faEnvelope, faMapMarkerAlt } from "@fortawesome/free-solid-svg-icons";
import { faFacebook, faInstagram, faTwitter, faYoutube } from "@fortawesome/free-brands-svg-icons";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section about">
            <h3>All In One Multi Cuisine Restaurant</h3>
            <p>Fine dining experience with a focus on quality ingredients and exceptional service.</p>
            <div className="contact">
              <span><FontAwesomeIcon icon={faPhone} /> (123) 456-7890</span>
              <span><FontAwesomeIcon icon={faEnvelope} /> info@gourmethaven.com</span>
            </div>
            <div className="address">
              <p><FontAwesomeIcon icon={faMapMarkerAlt} /> 123 Gourmet Street, Foodville, FC 12345</p>
            </div>
          </div>

          <div className="footer-section links">
            <h3>Quick Links</h3>
            <ul>
              <li><a href="/">Home</a></li>
              <li><a href="/categories">Categories</a></li>
              <li><a href="/foods">Our Menu</a></li>
              <li><a href="/orders">Orders</a></li>
              <li><a href="/login">Login</a></li>
              <li><a href="/admin">Admin Login</a></li>
              <li><a href="/cart">Cart</a></li>
            </ul>
          </div>

          <div className="footer-section contact-form">
            <h3>Contact Us</h3>
            <form>
              <input type="email" placeholder="Your Email" className="text-input" />
              <textarea placeholder="Your Message" className="text-input"></textarea>
              <button type="submit" className="btn">Send</button>
            </form>
          </div>

          <div className="footer-section social">
            <h3>Follow Us</h3>
            <div className="social-links">
              <a href="#"><FontAwesomeIcon icon={faFacebook} /></a>
              <a href="#"><FontAwesomeIcon icon={faInstagram} /></a>
              <a href="#"><FontAwesomeIcon icon={faTwitter} /></a>
              <a href="#"><FontAwesomeIcon icon={faYoutube} /></a>
            </div>
          </div>
        </div>

        <div className="footer-bottom">
          <h4>©2023 All In One Multi Cuisine Restaurant | Designed by Restaurant Team</h4>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
