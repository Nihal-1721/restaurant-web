import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";

const FoodForm = () => {
  const { id } = useParams();     
  const navigate = useNavigate();

  const [form, setForm] = useState({
    id: "",
    name: "",
    price: "",
    category_name: "",
    description: "",
  });

  const API = "http://localhost/backend-php";

  useEffect(() => {
  if (id) {
    axios
      .get(`${API}/get_foodbyId.php?food_id=${id}`)
      .then((res) => {
        if (res.data.success) {
          setForm({
            id: res.data.food.food_id,
            name: res.data.food.name,
            price: res.data.food.price,
            category_name: res.data.food.category_name,
            description: res.data.food.description
          });
        } else {
          alert("Food not found!");
        }
      })
      .catch(() => alert("Error loading food data"));
  }
}, [id]);


  // ✔ Handle form submission (Add or Update)
  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("id", form.id);
    formData.append("name", form.name);
    formData.append("price", form.price);
    formData.append("category_name", form.category_name);
    formData.append("description", form.description);

    try {
      let url = form.id ? `${API}/update_food.php` : `${API}/add_food.php`;

      const res = await axios.post(url, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      if (res.data.success) {
        alert(form.id ? "Food Updated Successfully!" : "Food Added Successfully!");
        navigate("/Foods"); // Redirect after success
      } else {
        alert("Error: " + res.data.message);
      }
    } catch (error) {
      console.log(error);
      alert("❌ Something went wrong!");
    }
  };

  return (
    <div className="food-container">
      <h2 className="title">{id ? "✏️ Edit Food Item" : "🍔 Add New Food"}</h2>

      <form className="food-form-card" onSubmit={handleSubmit}>
        <input type="hidden" value={form.id} />

        {/* NAME */}
        <div className="form-group">
          <label>Food Name</label>
          <input
            type="text"
            required
            value={form.name}
            placeholder="Enter food name"
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
        </div>

        {/* PRICE */}
        <div className="form-group">
          <label>Price (₹)</label>
          <input
            type="number"
            required
            // min="1"
            value={form.price}
            placeholder="Enter price"
            onChange={(e) => setForm({ ...form, price: e.target.value })}
          />
        </div>

        {/* CATEGORY */}
        <div className="form-group">
          <label>Category</label>
          <select
            required
            value={form.category_name}
            onChange={(e) => setForm({ ...form, category_name: e.target.value })}
          >
            <option value="">Choose category</option>
            <option>Appetizers</option>
            <option>Main Course</option>
            <option>Desserts</option>
            <option>Beverages</option>
          </select>
        </div>

        {/* DESCRIPTION */}
        <div className="form-group">
          <label>Description</label>
          <textarea
            required
            rows="4"
            value={form.description}
            placeholder="Enter food description"
            onChange={(e) => setForm({ ...form, description: e.target.value })}
          ></textarea>
        </div>

        {/* SUBMIT */}
        <button className="submit-btn" type="submit">
          {form.id ? "Update Food Item" : "Add Food Item"}
        </button>
      </form>
    </div>
  );
};

export default FoodForm;
