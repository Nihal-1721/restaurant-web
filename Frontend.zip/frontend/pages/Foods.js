import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import Bruschetta from "../images/gallery_44.webp"
import Spring_Rolls from "../images/gallery_4.jpg"
import Steak from "../images/gallery_16.jpg"
import Pasta from "../images/menu_10.jpg"
import Tiramisu from "../images/italian/Tiramisu.jpeg"
import Chocolate from "../images/dessert/Chocolate Lava Cake.jpeg"
import Lemonade from "../images/beverages/Fresh Lemonade.jpeg"
import Tea from "../images/beverages/Iced Tea.jpeg"
import { updateCartStorage } from "../pages/cartUtils";


const Foods = () => {
  const [category, setCategory] = useState("all");
  const [isAdmin, setIsAdmin] = useState(false);
  const [items, setItems] = useState([]);
  const navigate = useNavigate();

  const foodImages = {
    "Bruschetta": Bruschetta,
    "Spring Rolls": Spring_Rolls,
    "Grilled Steak": Steak,
    "Creamy Pasta": Pasta,
    "Tiramisu": Tiramisu,
    "Chocolate Lava Cake": Chocolate,
    "Fresh Lemonade": Lemonade,
    "Iced Tea": Tea
  };

  useEffect(() => {
    fetchFoods();

    const user = JSON.parse(localStorage.getItem("user"));
    setIsAdmin(user?.is_admin === true);
  }, []);

  const fetchFoods = async () => {
    try {
      const res = await axios.get("http://localhost/backend-php/get_food.php");

      console.log("Fetched data:", res.data);

      if (res.data.success === true) {
        setItems(res.data.foods);
      } else {
        console.error("PHP Response Error:", res.data.error);
      }
    } catch (err) {
      console.error("Fetch Error:", err);
    }
  };

  const handleEdit = (id) => {
    navigate(`/form/${id}`);
  };

  const handleDelete = async (food_id) => {
    const formData = new FormData();
    formData.append("food_id", food_id);

    try {
      const res = await axios.post(
        "http://localhost/backend-php/delete_food.php",
        formData
      );

      if (res.data.success) {
        alert("Food deleted successfully");
        fetchFoods();
      } else {
        alert("Delete failed: " + res.data.message);
      }
    } catch (err) {
      console.log("Delete Error:", err);
    }
  };

  const addToCart = (product) => {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    // check if item already exists
    const exists = cart.find(item => item.food_id === product.food_id);

    if (exists) {
      exists.qty += 1;
    } else {
      cart.push({
        food_id: product.food_id,
        name: product.name,
        desc: product.description,
        price: product.price,
        img: foodImages[product.name],
        qty: 1
      });
    }

    updateCartStorage(cart);
    localStorage.setItem("cart", JSON.stringify(cart));
    // alert("Item added to cart");
  };


  // Filter by category
  const filteredItems =
    category === "all"
      ? items
      : items.filter((i) => i.category_name === category);

  return (
    <section className="menu">
      <div className="container">
        <h2 className="menu-title">Our Menu</h2>

        {/* CATEGORY BUTTONS */}
        <div className="menu-filters">
          {["all", "Appetizers", "Main Course", "Desserts", "Beverages"].map(
            (category_name) => (
              <button
                key={category_name}
                className={`filter-btn ${category === category_name ? "active" : ""}`}
                onClick={() => setCategory(category_name)}
              >
                {category_name === "all"
                  ? "All Items"
                  : category_name.replace("-", " ").replace(/\b\w/g, (c) => c.toUpperCase())}
              </button>
            )
          )}
          {isAdmin && (
            <Link to="/form">
              <button className="filter-btn add-btn">Add/Manage Items</button>
            </Link>
          )}
        </div>

        {/* FOOD LIST */}
        <div className="menu-items">
          {filteredItems.length === 0 ? (
            <p>No items found.</p>
          ) : (
            filteredItems.map((item) => (
              <div className="menu-item" key={item.id}>
                <img
                  src={foodImages[item.name] || "/images/default.jpg"}
                  alt={item.name}
                  className="menu-img"
                />
                <div className="item-info">
                  <h3>{item.name}</h3>
                  <p>{item.description}</p>
                  <div className="item-footer">
                    <span className="price">₹{item.price}</span>
                    {isAdmin ? (
                      <>
                        <button
                          className="add-to-cart admin-edit-btn"
                          onClick={() => handleEdit(item.food_id)}
                        >
                          Edit
                        </button>

                        <button
                          className="add-to-cart admin-delete-btn"
                          onClick={() => handleDelete(item.food_id)}
                        >
                          Delete
                        </button>
                      </>
                    ) : (
                      <button
                        className="add-to-cart"
                        onClick={() => addToCart(item)}
                      >
                        Add to Cart
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default Foods;
