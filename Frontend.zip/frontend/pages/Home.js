import React from "react";
import { Link } from "react-router-dom";
import RestaurantInterior from "../images/restaurant-interior.jpg";
import Menu10 from "../images/menu_10.jpg";
import Menu04 from "../images/menu_4.jpg";
import Menu19 from "../images/menu_19.jpg";

const Home = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="hero">
        <div className="container">
          <h1>Welcome to All In One Multi Cuisine Restaurant</h1>
          <p>
            Experience culinary excellence with our handcrafted dishes made
            from the finest ingredients
          </p>
          <Link to="/foods" className="btn">
            Explore Menu
          </Link>
        </div>
      </section>

      {/* About Section */}
      <section className="about">
        <div className="container">
          <h2>About Our Restaurant</h2>
          <div className="about-content">
            <div className="about-text">
              <p>
                Founded in 2010, Gourmet Haven has been serving authentic cuisine
                with a modern twist. Our chefs combine traditional recipes with
                innovative techniques to create unforgettable dining experiences.
              </p>
              <p>
                We source our ingredients locally whenever possible, ensuring
                freshness and supporting our community. Our menu changes
                seasonally to reflect the best produce available.
              </p>
            </div>
            <div className="about-image">
              <img src={RestaurantInterior} alt="Restaurant Interior" />
            </div>
          </div>
        </div>
      </section>

      {/* Specials */}
      <section className="offers">
        <div className="container">
          <h2>Today's Specials</h2>
          <div className="offer-items">
            <div className="offer-item">
              <img src={Menu10} alt="Special Dish 1" />
              <h3>Truffle Pasta</h3>
              <p className="price">
                $18.99 <span className="old-price">$24.99</span>
              </p>
            </div>
            <div className="offer-item">
              <img src={Menu04} alt="Special Dish 2" />
              <h3>Grilled Salmon</h3>
              <p className="price">
                $22.99 <span className="old-price">$28.99</span>
              </p>
            </div>
            <div className="offer-item">
              <img src={Menu19} alt="Special Dish 3" />
              <h3>Chocolate Fondant</h3>
              <p className="price">
                $9.99 <span className="old-price">$12.99</span>
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
