import React, { useState, useEffect } from "react";
import axios from "axios";

const Orders = () => {
  const [activeTab, setActiveTab] = useState("current");
  const [orders, setOrders] = useState([]);

  const storedUser = JSON.parse(localStorage.getItem("loggedUser"));
  const user_id = storedUser?.user_id;

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = () => {
    if (!user_id) return;

    axios
      .get(`http://localhost/backend-php/get_orders.php?user_id=${user_id}`)
      .then((res) => {
        if (res.data.success) {
          setOrders(res.data.orders);
        }
      })
      .catch((err) => console.log(err));
  };

  // 🔥 CANCEL ORDER FUNCTION
  const cancelOrder = async (order_id) => {
    if (!window.confirm("Are you sure you want to cancel this order?")) return;

    try {
      const res = await axios.post(
        "http://localhost/backend-php/update_order_status.php",
        {
          order_id: order_id,
          status: "Cancelled",
        }
      );

      if (res.data.success) {
        alert("Order Cancelled Successfully!");
        fetchOrders(); // Reload orders
      } else {
        alert("Failed to cancel order.");
      }
    } catch (err) {
      console.log(err);
      alert("Error cancelling order.");
    }
  };

  // 👇 UPDATED FILTER LOGIC
  const currentOrders = orders.filter(
    (o) => o.status === "Pending" || o.status === "Preparing"
  );

  const pastOrders = orders.filter(
    (o) => o.status === "Delivered" || o.status === "Cancelled"
  );

  // 🔥 REORDER FUNCTION
  const reorder = (order) => {
    let newCart = [];

    order.items.forEach((item) => {
      newCart.push({
        food_id: item.food_id,
        name: item.name,
        img: item.image || item.img || "",   // if backend sends image
        desc: item.description || item.desc || "",
        price: Number(item.price_item),      // your backend column
        qty: Number(item.quantity)           // convert to qty
      });
    });

    localStorage.setItem("cart", JSON.stringify(newCart));

    window.location.href = "/cart";
  };


  return (
    <section className="orders">
      <div className="container">
        <h2>My Orders</h2>

        <div className="order-tabs">
          <button
            className={`tab-btn ${activeTab === "current" ? "active" : ""}`}
            onClick={() => setActiveTab("current")}
          >
            Current Orders
          </button>

          <button
            className={`tab-btn ${activeTab === "past" ? "active" : ""}`}
            onClick={() => setActiveTab("past")}
          >
            Past Orders
          </button>
        </div>

        <div className="order-content">
          {(activeTab === "current" ? currentOrders : pastOrders).map(
            (order) => (
              <div className="order-card" key={order.order_id}>
                <div className="order-header">
                  <h3>Order #{order.order_id}</h3>
                  <span className={`status ${order.status.toLowerCase()}`}>
                    {order.status}
                  </span>
                </div>

                <div className="order-details">
                  <p>
                    <strong>Order Date:</strong> {order.order_date}
                  </p>
                  <p>
                    <strong>Items:</strong>
                  </p>

                  <table
                    className="order-items-table"
                    style={{ border: "2px solid black" }}
                  >
                    <thead>
                      <tr>
                        <th>Item</th>
                        <th>Quantity</th>
                        <th>Price</th>
                      </tr>
                    </thead>

                    <tbody>
                      {order.items.map((item) => (
                        <tr key={item.item_id}>
                          <td>{item.name}</td>
                          <td>{item.quantity}</td>
                          <td>₹{item.price_item}</td>
                        </tr>
                      ))}

                      <tr>
                        <td>
                          <b>Total Amount</b>
                        </td>
                        <td></td>
                        <td>₹{order.total_amount}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* BUTTONS */}
                {activeTab === "current" ? (
                  <div>
                    <button className="btn track-order">Track Order</button>

                    {order.status === "Pending" && (
                      <button
                        className="btn cancel-order"
                        onClick={() => cancelOrder(order.order_id)}
                      >
                        Cancel Order
                      </button>
                    )}
                  </div>
                ) : (
                  <button className="btn reorder" onClick={() => reorder(order)}>Reorder</button>
                )}
              </div>
            )
          )}
        </div>
      </div>
    </section>
  );
};

export default Orders;
