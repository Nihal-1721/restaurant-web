export const updateCartStorage = (cart) => {
  localStorage.setItem("cart", JSON.stringify(cart));

  // send update event to all components
  window.dispatchEvent(new Event("cartUpdated"));
};

export const getCartCount = () => {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  return cart.reduce((sum, item) => sum + item.qty, 0);
};
