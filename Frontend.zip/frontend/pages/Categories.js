import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Appetizers from "../images/japanese/Sushi Platter.jpeg";
import Main_cource from "../images/indian/chole-bhature.jpeg";
import Desserts from "../images/dessert/Tiramisu.jpeg";
import Beverages from "../images/beverages/Fresh Orange Juice.jpeg";
import Salads from "../images/mediterranean/Hummus.jpeg";
import Chef from "../images/thai/Chicken Satay.jpeg";

const Categories = () => {
  const [data, setData] = useState([]);
  const categoryImages = {
    "appetizers": Appetizers,
    "main-course": Main_cource,
    "desserts": Desserts,
    "beverages": Beverages,
    "salads": Salads,
    "specials": Chef,
  };

  const categoryLink= "/foods?category=allitem";

  useEffect(() => {
    fetch("http://localhost/backend-php/fetch_categories.php")
      .then((res) => res.json())
      .then((data) => setData(data));
  }, []);

  return (
    <section className="Categories">
      <div className="container">
        <h2>Our Food Categories</h2>

        <div className="category-grid">
          {data.map((item) => (
            <div className="category-card" key={item.id}>

              <img 
                src={categoryImages[item.slug]} 
                alt={item.title} 
              />

              <div className="category-info">
                <h3>{item.name}</h3>
                <p>{item.description}</p>

                <Link to={categoryLink} className="btn">
                  View Items
                </Link>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

export default Categories;
