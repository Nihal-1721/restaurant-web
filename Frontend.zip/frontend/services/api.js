import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost/restaurant-app/backend-php", // path to your PHP folder
});

export default api;
